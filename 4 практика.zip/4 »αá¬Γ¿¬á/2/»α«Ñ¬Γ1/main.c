#include <8051.h>

#define LED_PORT P1

void delay(unsigned int t) {
    unsigned int i, j;
    for (i = 0; i < t; i++)
        for (j = 0; j < 8; j++);
}

void main() {
    unsigned char leds[] = {0x02, 0x04, 0x20, 0x40, 0x81, 0x18,};
    unsigned int intervals[] = {1500, 1500, 2500,2500,5000,5000}; 
    int i;
    while (1) {
        for ( i = 0; i < 6; i++) {
            LED_PORT = leds[i];
            delay(intervals[i]);
        }
    }
}
